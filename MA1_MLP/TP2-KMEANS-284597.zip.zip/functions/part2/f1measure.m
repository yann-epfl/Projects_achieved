function [F1_overall, P, R, F1] =  f1measure(cluster_labels, class_labels)
%MY_F1MEASURE Computes the f1-measure for semi-supervised clustering
%
%   input -----------------------------------------------------------------
%   
%       o class_labels     : (1 x M),  M-dimensional vector with true class
%                                       labels for each data point
%       o cluster_labels   : (1 x M),  M-dimensional vector with predicted 
%                                       cluster labels for each data point
%   output ----------------------------------------------------------------
%
%       o F1_overall      : (1 x 1)     f1-measure for the clustered labels
%       o P               : (nClusters x nClasses)  Precision values
%       o R               : (nClusters x nClasses)  Recall values
%       o F1              : (nClusters x nClasses)  F1 values
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

M = size(class_labels, 2);
nClasses = max(class_labels);
nClusters = max(cluster_labels);

P=zeros(nClusters, nClasses);
R=zeros(nClusters, nClasses);
F1=zeros(nClusters, nClasses);

F1_overall=0;

for j=1 : nClasses
    
    cj = sum(class_labels==j); %% tot nb of el in cj
    
    for i=1 : nClusters
        k=sum(cluster_labels==i); %% tot nb of el in ki
        idx1 = (class_labels==j);
        idx2 = (class_labels==j)==(cluster_labels==i);
        
        nik=sum(idx1(idx2)); %%nb of el of class cj in ki
        
        P(i,j)=nik/k;
        R(i,j)=nik/cj;
        
        if(R(i,j)+P(i,j)==0)
            F1(i,j)=0;
        else
            F1(i,j)=(2*R(i,j)*P(i,j))/(R(i,j)+P(i,j));
        end
        
%         for k=1 : M
%             if(class_labels(k)==j && cluster_labels(k)==i)
%                 P(i,j) = P(i,j)+1;
%             end
%         end
    end
    
    F1_overall = F1_overall+(cj/M)*max(F1(:,j));
end



end

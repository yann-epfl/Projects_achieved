function [ Sigma ] = compute_covariance( X, X_bar, type )
%MY_COVARIANCE computes the covariance matrix of X given a covariance type.
%
% Inputs -----------------------------------------------------------------
%       o X     : (N x M), a data set with M samples each being of dimension N.
%                          each column corresponds to a datapoint
%       o X_bar : (N x 1), an Nx1 matrix corresponding to mean of data X
%       o type  : string , type={'full', 'diag', 'iso'} of Covariance matrix
%
% Outputs ----------------------------------------------------------------
%       o Sigma : (N x N), an NxN matrix representing the covariance matrix of the 
%                          Gaussian function
%%
[N, M] = size(X);

if(strcmp(type, 'full'))
    X = X-X_bar;
    Sigma = 1/(M-1)*(X*X');
end

if(strcmp(type, 'diag'))
    X = X-X_bar;
    Sigma = 1/(M-1)*(X*X');
    Sigma = diag(diag(Sigma));
end

if(strcmp(type, 'iso'))
    sigm_iso = 0;
    for i=1 : M
        sigm_iso = sigm_iso + (norm(X(:,i)-X_bar))^2;
    end
    sigm_iso = sigm_iso/(N*M);
    Sigma = sigm_iso*eye(N);
end

end


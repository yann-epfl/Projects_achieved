function [Priors,Mu,Sigma] = maximization_step(X, Pk_x, params)
%MAXIMISATION_STEP Compute the maximization step of the EM algorithm
%   input------------------------------------------------------------------
%       o X         : (N x M), a data set with M samples each being of 
%       o Pk_x      : (K, M) a KxM matrix containing the posterior probabilty
%                     that a k Gaussian is responsible for generating a point
%                     m in the dataset, output of the expectation step
%       o params    : The hyperparameters structure that contains k, the number of Gaussians
%                     and cov_type the coviariance type
%   output ----------------------------------------------------------------
%       o Priors    : (1 x K), the set of updated priors (or mixing weights) for each
%                           k-th Gaussian component
%       o Mu        : (N x K), an NxK matrix corresponding to the updated centroids 
%                           mu = {mu^1,...mu^K}
%       o Sigma     : (N x N x K), an NxNxK matrix corresponding to the
%                   updated Covariance matrices  Sigma = {Sigma^1,...,Sigma^K}
%%

[N, M] = size(X);
K = size(Pk_x, 1);

epsilon = 1e-5;

sum_Pk_x = sum(Pk_x, 2);

Priors = ((1/M)*sum_Pk_x)';

Mu = zeros(N,K);

for k=1 : K
    Mu(:,k) = sum(Pk_x(k,:).*X,2)/sum_Pk_x(k);
end

type = params.cov_type;

if(strcmp(type, 'diag') || strcmp(type, 'full'))
    Sigma = zeros(N,N,K);
    for k=1 : K
        Sigma(:,:,k) = (repmat(Pk_x(k,:),N,1).*(X-Mu(:,k))*(X-Mu(:,k))')./sum_Pk_x(k);
        Sigma(:,:,k) = Sigma(:,:,k)+eye(N)*epsilon;
    end
end

if(strcmp(type, 'diag'))
    for k=1 : K
        Sigma(:,:,k) = diag(diag(Sigma(:,:,k)));
    end
end

if(strcmp(type, 'iso'))
    Sigma_iso = zeros(N,N,K);
    for k=1 : K
        iso = (Pk_x(k,:)*(sum((X-Mu(:,k)).*(X-Mu(:,k)),1))')./(N*sum_Pk_x(k));
        Sigma_iso(:,:,k) = eye(N)*(iso+epsilon);
    end
    Sigma = Sigma_iso;
end

% for k=1 : K
%     for i=1 : M
%         somme = Pk_x(k,i)*X(:,i);
%     end
%     Mu(:,k) = somme/sum_Pk_x(k);
% end


end


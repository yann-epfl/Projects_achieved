function [MSE, NMSE, Rsquared] = regression_metrics( yest, y )
%REGRESSION_METRICS Computes the metrics (MSE, NMSE, R squared) for 
%   regression evaluation
%
%   input -----------------------------------------------------------------
%   
%       o yest  : (P x M), representing the estimated outputs of P-dimension
%       of the regressor corresponding to the M points of the dataset
%       o y     : (P x M), representing the M continuous labels of the M 
%       points. Each label has P dimensions.
%
%   output ----------------------------------------------------------------
%
%       o MSE       : (1 x 1), Mean Squared Error
%       o NMSE      : (1 x 1), Normalized Mean Squared Error
%       o R squared : (1 x 1), Coefficent of determination
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[P,M] = size(y);

MSE = (1/M)*sum(sum((yest-y).*(yest-y)));

mu = (1/M)*sum(y,2);
var = (1/(M-1))*sum(sum((y-mu).*(y-mu)));
NMSE = MSE/var;

avg_y = mu;
avg_yest = (1/M)*sum(yest,2);

num = sum((y-avg_y).*(yest-avg_yest),2);
num = num * num;
denom = sum((y-avg_y).*(y-avg_y),2)*sum((yest-avg_yest).*(yest-avg_yest),2);
Rsquared = num/denom;


end


function [dZ] = backward_activation(Z, Sigma)
%BACKWARD_ACTIVATION Compute the derivative of the activation function
%evaluated in Z
%   inputs:
%       o Z (NxM) Z value, input of the activation function. The size N
%       depends of the number of neurons at the considered layer but is
%       irrelevant here.
%       o Sigma (string) type of the activation to use
%   outputs:
%       o dZ (NXM) derivative of the activation function

k=0.01;

switch Sigma
    case 'sigmoid'
        dZ = exp(-Z)./((1 + exp(-Z)).^2);
        
    case 'tanh'
        dZ = 4./((exp(-Z) + exp(Z)).^2);
        
    case 'relu'
        dZ = Z>=0;
        
    case 'leakyrelu'
        dZ = Z>=0;
        idx = Z<0;
        dZ = dZ+idx*k;
end

end

